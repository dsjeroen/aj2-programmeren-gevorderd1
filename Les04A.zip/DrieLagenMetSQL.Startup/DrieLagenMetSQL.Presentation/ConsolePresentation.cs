﻿namespace DrieLagenMetSQL.Presentation
{
    public class ConsolePresentation
    {
    }
}
