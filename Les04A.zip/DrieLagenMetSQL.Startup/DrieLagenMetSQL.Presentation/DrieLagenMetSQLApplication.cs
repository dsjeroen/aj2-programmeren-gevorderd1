﻿using DrieLagenMetSQL.Domain;
using DrieLagenMetSQL.Domain.DTO;

namespace DrieLagenMetSQL.Presentation
{
    public class DrieLagenMetSQLApplication
    {
        private readonly DomainController _controller;
        private readonly ConsolePresentation _ui;

        public DrieLagenMetSQLApplication(DomainController controller, ConsolePresentation ui)
        {
            _controller = controller;
            _ui = ui;
        }

        public void Run()
        {
            _ui.Writeline("Naam?");
        }
    }
}
