﻿namespace DrieLagenMetSQL.Domain.DTO
{
    /// <summary>
    /// Data Transfer Object (DTO) gebruikt voor communicatie tussen UI, Domain en Persistence.
    /// 
    /// Deze klasse bevat enkel de data die we doorgeven tussen lagen. Er zit GEEN logica in.
    /// DTO's zijn ideaal om:
    /// - Input van de gebruiker door te geven aan de DomainController.
    /// - Resultaten terug te sturen naar de UI.
    /// 
    /// Reden van bestaan:
    /// We willen vermijden dat UI of opslagdetails de Domein-entiteit beïnvloeden.
    /// DTO is dus een "platte" en veilige vorm van de data.
    /// </summary>
    
    public class ProductDTO
    {
        public int Id { get; set; }
        public string Naam { get; set; } = "";
        public decimal Prijs { get; set; }
        public int Voorraad { get; set; }
    }
}
