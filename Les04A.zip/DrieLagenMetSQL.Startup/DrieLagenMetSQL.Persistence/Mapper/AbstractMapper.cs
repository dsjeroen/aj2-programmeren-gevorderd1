﻿namespace DrieLagenMetSQL.Persistence.Mapper
{
    /// <summary>
    /// Basisimplementatie met lijst-helpers;
    /// Het zorgt dat we gedeelde mapping-logica niet hoeven dupliceren.
    /// Enkel de unieke mapping moet je in de subklasse invullen.
    /// </summary>

    public abstract class AbstractMapper<TDto, TModel> :IMapper<TDto, TModel>
    {
        public List<TDto> MapToDTO(List<TModel> models)
        {
            var result = new List<TDto>(models.Count);
            foreach (var model in models)
                result.Add(MapToDTO(model)!);
            return result;
        }

        public List<TModel> MapToModel(List<TDto> dtos)
        {
            var result = new List<TModel>(dtos.Count);
            foreach (var dto in dtos)
                result.Add(MapToModel(dto)!);
            return result;
        }

        public abstract TDto? MapToDTO(TModel model);
        public abstract TModel? MapToModel(TDto dto);
    }
}
