﻿namespace DrieLagenMetSQL.Persistence.Mapper
{
    /// <summary>
    /// Generiek contract voor vertaling tussen transport (DTO) en opslag (Model).
    /// Het zorgt dat we tegen een abstractie kunnen programmeren, en dus mappers 
    /// kunnen wisselen / mocken / injecteren.
    /// Houdt mapping buiten Domain en centraliseert het in Persistence.
    /// </summary>

    public interface IMapper<TDto, TModel>
    {
        TDto? MapToDTO(TModel model);
        TModel? MapToModel(TDto dto);
        List<TDto> MapToDTO(List<TModel> models);
        List<TModel> MapToModel(List<TDto> dtos);
    }
}
