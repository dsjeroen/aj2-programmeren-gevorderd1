﻿using DrieLagenMetSQL.Domain.DTO;
using DrieLagenMetSQL.Persistence.Model;

namespace DrieLagenMetSQL.Persistence.Mapper.Impl
{
    /// <summary>
    /// Concrete mapper tussen transportvorm (vb. ProductDTO) en opslagvorm (vb. ProductModel).
    /// - Houdt mapping buiten Domain en centraliseert dit in Persistence.
    /// - Bevat geen businesslogica; optioneel lichte normalisatie (bv. Trim) is oké.
    /// </summary>

    public class ProductMapper :AbstractMapper<ProductDTO, ProductModel>
    {
        public override ProductDTO MapToDTO(ProductModel model)
        {
            // Geen businesslogica hier; pure veld-naar-veld mapping.
            return new ProductDTO
            {
                Id = model.Id,
                Naam = model.Naam,
                Prijs = model.Prijs,
                Voorraad = model.Voorraad
            };
        }

        public override ProductModel MapToModel(ProductDTO dto)
        {
            // Lichte normalisatie kan (bv. Trim op strings); geen validatieregels hier.
            return new ProductModel
            {
                Id = dto.Id,
                Naam = dto.Naam?.Trim() ?? string.Empty,
                Prijs = dto.Prijs,
                Voorraad = dto.Voorraad
            };
        }
    }
}
