﻿namespace DrieLagenMetSQL.Persistence.Model
{
    /// <summary>
    /// Opslagmodel dat de interne representatie van vb. "Product" voorstelt in de Persistence-laag.
    ///
    /// Dit model wordt gebruikt binnen repositories en mappers om data op te slaan of uit de database te lezen.
    ///
    /// Belangrijk:
    /// - Dit model is gekoppeld aan opslag (bv. list in memory, SQL tabel, JSON, ...).
    /// - Wordt NIET gebruikt door de UI.
    /// - Wordt NIET rechtstreeks gebruikt in de Domain-laag.
    /// - De structuur kan afwijken van de domein-entiteit wanneer opslagvereisten verschillen.
    ///
    /// Vergelijking (met vb. "Product"):
    /// Product         = businessentiteit (betekenis en regels).
    /// ProductDTO      = uitwisselingsvorm (transport tussen lagen).
    /// ProductModel    = opslagstructuur (representatie in database / repository).
    /// </summary>

    public class ProductModel
    {
        public int Id { get; set; }
        public string Naam { get; set; } = "";
        public decimal Prijs { get; set; }
        public int Voorraad { get; set; }
    }
}
