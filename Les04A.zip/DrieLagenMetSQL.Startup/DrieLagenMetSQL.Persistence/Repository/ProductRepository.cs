﻿using System.Data;
using Microsoft.Data.SqlClient; // NuGet: Microsoft.Data.SqlClient
using DrieLagenMetSQL.Domain.DTO;
using DrieLagenMetSQL.Domain.Repository;
using DrieLagenMetSQL.Persistence.Mapper.Impl;
using DrieLagenMetSQL.Persistence.Model;

namespace DrieLagenMetSQL.Persistence.Repository
{
    /// <summary>
    /// SQL-repository: slaat ProductModel op in tabel [Products]
    /// en expose't ProductDTO" naar buiten.
    /// 
    /// Verwachte tabel (schets):
    ///   CREATE TABLE [dbo].[Products] (
    ///     [Id] INT IDENTITY(1,1) PRIMARY KEY,
    ///     [Naam] NVARCHAR(200) NOT NULL,
    ///     [Prijs] DECIMAL(18,2) NOT NULL,
    ///     [Voorraad] INT NOT NULL
    ///   );
    /// 
    /// Afhankelijkheden:
    /// - IDbConnectionFactory (wordt in volgende stap toegevoegd)
    /// - ProductMapper voor DTO ↔ Model
    /// </summary>

    public class ProductRepository :IRepository<ProductDTO>
    {
        private readonly IDbConnectionFactory _db;     // wordt in Startup geïnjecteerd
        private readonly ProductMapper _mapper = new(); // eenvoudige veld-mapping

        // SQL-commando's als const's voor overzicht
        private const string SqlSelectAll = @"
            SELECT Id, Naam, Prijs, Voorraad
            FROM   dbo.Products;";

        private const string SqlInsert = @"
            INSERT INTO dbo.Products (Naam, Prijs, Voorraad)
            VALUES (@Naam, @Prijs, @Voorraad);
            SELECT CAST(SCOPE_IDENTITY() AS int);";

        private const string SqlUpdate = @"
            UPDATE dbo.Products
            SET    Naam = @Naam,
                   Prijs = @Prijs,
                   Voorraad = @Voorraad
            WHERE  Id = @Id;";

        private const string SqlDelete = @"
            DELETE FROM dbo.Products
            WHERE  Id = @Id;";

        public ProductRepository(IDbConnectionFactory db)
        {
            _db = db;
        }
    }
}
