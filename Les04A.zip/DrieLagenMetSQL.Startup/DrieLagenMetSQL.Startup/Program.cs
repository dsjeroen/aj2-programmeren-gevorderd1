﻿using DrieLagenMetSQL.Domain;
using DrieLagenMetSQL.Domain.DTO;
using DrieLagenMetSQL.Domain.Repository;
using DrieLagenMetSQL.Persistence.Infrastructure;
using DrieLagenMetSQL.Persistence.Repository;
using DrieLagenMetSQL.Presentation;

namespace DrieLagenMetSQL.Startup
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // 1) Connection string centraal bepalen
            var connectionString =
                "Server=(localdb)\\MSSQLLocalDB;Database=DrieLagenDb;" +
                "Trusted_Connection=True;MultipleActiveResultSets=True;";

            // 2) Factory maken
            var dbFactory = new SqlConnectionFactory(connectionString);

            IRepository<ProductDTO> productRepo = new ProductRepository(dbFactory);     // concrete keuze
            var controller = new DomainController(productRepo);                         // injectie
            var ui = new ConsolePresentation();                                         // console I/O
            var app = new DrieLagenMetSQLApplication(controller, ui);                   // use-case orchestratie

            app.Run();


            Console.ReadKey();
        }
    }
}
