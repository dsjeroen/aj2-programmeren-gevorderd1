﻿namespace Oef03_Rekening
{
    internal class Program
    {
        static void Main(string[] args)
        {


            Console.ReadKey();
        }
    }
}
