﻿namespace Les3Lagen.Startup
{
    internal class Startup
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello, World!");
        }
    }
}
