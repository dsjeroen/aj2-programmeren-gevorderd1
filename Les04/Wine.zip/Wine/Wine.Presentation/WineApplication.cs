﻿using Wine.Domain;

namespace Wine.Presentation
{
    public class WineApplication
    {
        private readonly DomainManager _domainManager;
        public WineApplication(DomainManager domainManager)
        {
            _domainManager = domainManager;
        }
    }
}
