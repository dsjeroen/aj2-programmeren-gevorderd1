﻿using Wine.Domain.Model;
using Wine.Domain.Repository;

namespace Wine.Persistence
{
    public class WineMapper :IWineRepository
    {
        public List<Bottle> GetallBottles()
        {
            throw new NotImplementedException();
        }
    }
}
