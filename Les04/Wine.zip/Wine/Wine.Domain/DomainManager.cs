﻿using Wine.Domain.Repository;

namespace Wine.Domain
{
    public class DomainManager
    {
        private readonly IWineRepository _repository;
        public DomainManager(IWineRepository repository)
        {
            _repository = repository;
        }
    }
}
